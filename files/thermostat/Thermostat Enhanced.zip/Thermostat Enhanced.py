#
# Thermostat - This is the Python code used to demonstrate
# the functionality of the thermostat that we have prototyped throughout
# the course. 
#
# This code works with the test circuit that was built for module 7.
#
# Functionality:
#
# The thermostat has three states: off, heat, cool
#
# The lights will represent the state that the thermostat is in.
#
# If the thermostat is set to off, the lights will both be off.
#
# If the thermostat is set to heat, the Red LED will be fading in 
# and out if the current temperature is blow the set temperature;
# otherwise, the Red LED will be on solid.
#
# If the thermostat is set to cool, the Blue LED will be fading in 
# and out if the current temperature is above the set temperature;
# otherwise, the Blue LED will be on solid.
#
# One button will cycle through the three states of the thermostat.
#
# One button will raise the setpoint by a degree.
#
# One button will lower the setpoint by a degree.
#
# The LCD display will display the date and time on one line and
# alternate the second line between the current temperature and 
# the state of the thermostat along with its set temperature.
#
# The Thermostat will send a status update to the TemperatureServer
# over the serial port every 30 seconds in a comma delimited string
# including the state of the thermostat, the current temperature
# in degrees Fahrenheit, and the setpoint of the thermostat.
#
#------------------------------------------------------------------
# Change History
#------------------------------------------------------------------
# Version   |   Description
#------------------------------------------------------------------
#    1          Initial Development
#------------------------------------------------------------------
#    2          Secondary Development
##
## Import necessary to provide timing in the main loop
##

##
## Import necessary files to support new functionality
##
import logging
from time import sleep
from datetime import datetime
from statemachine import StateMachine, State
import board
import adafruit_ahtx0
import digitalio
import adafruit_character_lcd.character_lcd as characterlcd
import serial
from gpiozero import Button, PWMLED
from threading import Thread
from math import floor

# ----------------------------
# Logging Setup (NEW)
# ----------------------------
logging.basicConfig(
    filename='thermostat.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

## Hardware Initialization

i2c = board.I2C()
thSensor = adafruit_ahtx0.AHTx0(i2c)

ser = serial.Serial(
    port='/dev/ttyS0',
    baudrate=115200,
    parity=serial.PARITY_NONE,
    stopbits=serial.STOPBITS_ONE,
    bytesize=serial.EIGHTBITS,
    timeout=1
)

redLight = PWMLED(18)
blueLight = PWMLED(23)

## Display Class 

class ManagedDisplay:
    def __init__(self):
        ##
        ## Setup the six GPIO lines to communicate with the display.
        ## This leverages the digitalio class to handle digital 
        ## outputs on the GPIO lines. There is also an analagous
        ## class for analog IO.
        ##
        ## You need to make sure that the port mappings match the
        ## physical wiring of the display interface to the 
        ## GPIO interface.
        ##
        ## compatible with all versions of RPI as of Jan. 2019
        ##
        self.lcd_rs = digitalio.DigitalInOut(board.D17)
        self.lcd_en = digitalio.DigitalInOut(board.D27)
        self.lcd_d4 = digitalio.DigitalInOut(board.D5)
        self.lcd_d5 = digitalio.DigitalInOut(board.D6)
        self.lcd_d6 = digitalio.DigitalInOut(board.D13)
        self.lcd_d7 = digitalio.DigitalInOut(board.D26)

        self.lcd = characterlcd.Character_LCD_Mono(
            self.lcd_rs, self.lcd_en,
            self.lcd_d4, self.lcd_d5,
            self.lcd_d6, self.lcd_d7,
            16, 2
        )

        self.lcd.clear()

    def updateScreen(self, message):
        self.lcd.clear()
        self.lcd.message = message

    def cleanupDisplay(self):
        self.lcd.clear()

screen = ManagedDisplay()

## Temperature State Machine - This is our StateMachine implementation class.
## The purpose of this state machine is to manage the three states
## handled by our thermostat:

class TemperatureMachine(StateMachine):

    off = State(initial=True)
    heat = State()
    cool = State()

    setPoint = 72

    cycle = off.to(heat) | heat.to(cool) | cool.to(off)

    ## Safe Temperature Read (NEW)
    
    def getFahrenheit(self):
        try:
            t = thSensor.temperature
            return ((9/5) * t) + 32
        except Exception as e:
            logging.error(f"Sensor read error: {e}")
            return 0

    ## State Transitions
    
    def on_enter_heat(self):
        logging.info("State changed to HEAT")
        self.updateLights()

    def on_enter_cool(self):
        logging.info("State changed to COOL")
        self.updateLights()

    def on_enter_off(self):
        logging.info("State changed to OFF")
        redLight.off()
        blueLight.off()

    ## Button Actions
    
    def processTempStateButton(self):
        logging.info("Cycling thermostat state")
        self.cycle()

    def processTempIncButton(self):
        self.setPoint += 1
        logging.info(f"SetPoint increased to {self.setPoint}")
        self.updateLights()

    def processTempDecButton(self):
        self.setPoint -= 1
        logging.info(f"SetPoint decreased to {self.setPoint}")
        self.updateLights()

    ## LED Logic
    
    def updateLights(self):
        temp = floor(self.getFahrenheit())

        redLight.off()
        blueLight.off()

        if self.current_state == self.heat:
            if temp < self.setPoint:
                redLight.pulse()
            else:
                redLight.on()

        elif self.current_state == self.cool:
            if temp > self.setPoint:
                blueLight.pulse()
            else:
                blueLight.on()

    ## Serial Output (ERROR HANDLING ADDED)
    
    def sendSerial(self):
        try:
            temp = floor(self.getFahrenheit())
            output = f"{self.current_state.id},{temp},{self.setPoint}\n"
            ser.write(output.encode())
            logging.info("Serial data sent")
        except Exception as e:
            logging.error(f"Serial error: {e}")

    
    ## Display Thread
    
    def manageDisplay(self):
        counter = 1

        while True:
            current_time = datetime.now()
            line1 = current_time.strftime("%m/%d %H:%M:%S") + "\n"

            temp = floor(self.getFahrenheit())
            line2 = f"{self.current_state.id} T:{temp} SP:{self.setPoint}"

            screen.updateScreen(line1 + line2)

            if counter % 30 == 0:
                self.sendSerial()
                counter = 1
            else:
                counter += 1

            sleep(1)

    def run(self):
        Thread(target=self.manageDisplay).start()

## Initialize System

tsm = TemperatureMachine()
tsm.run()

greenButton = Button(24)
greenButton.when_pressed = tsm.processTempStateButton

redButton = Button(25)
redButton.when_pressed = tsm.processTempIncButton

blueButton = Button(12)
blueButton.when_pressed = tsm.processTempDecButton

## Main Loop

try:
    while True:
        sleep(30)

except KeyboardInterrupt:
    logging.info("System shutdown initiated")
    screen.cleanupDisplay()
