import logging
import re
from typing import Any, Dict, List, Optional

from bson import ObjectId
from pymongo import MongoClient
from pymongo.errors import PyMongoError


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s"
)


class AnimalShelter:
    SAFE_QUERY_OPERATORS = {
        "$regex", "$options", "$gte", "$lte", "$gt", "$lt", "$eq", "$in", "$nin"
    }

    def __init__(
        self,
        username: Optional[str] = None,
        password: Optional[str] = None,
        host: str = "localhost",
        port: int = 27017,
        db_name: str = "AnimalShelterDB",
        collection_name: str = "animals",
        auth_source: Optional[str] = None
    ) -> None:
        self.logger = logging.getLogger(self.__class__.__name__)
        self.records_updated = 0
        self.records_matched = 0
        self.records_deleted = 0

        auth_source = auth_source or db_name

        try:
            if username and password:
                uri = f"mongodb://{username}:{password}@{host}:{port}/?authSource={auth_source}"
                self.client = MongoClient(uri)
            else:
                self.client = MongoClient(host=host, port=port)

            self.db = self.client[db_name]
            self.collection = self.db[collection_name]
            self.client.admin.command("ping")

            self.logger.info(
                "Connected to MongoDB at %s:%s, db=%s, collection=%s",
                host, port, db_name, collection_name
            )
        except PyMongoError as exc:
            self.logger.exception("Failed to connect to MongoDB.")
            raise ConnectionError("Could not connect to MongoDB.") from exc

    @staticmethod
    def _serialize_doc(doc: Dict[str, Any]) -> Dict[str, Any]:
        doc = dict(doc)
        if "_id" in doc:
            doc["_id"] = str(doc["_id"])
        return doc

    def _contains_unsafe_data_keys(self, payload: Any) -> bool:
        """For create/update payloads: block keys starting with $ or containing dots."""
        if isinstance(payload, dict):
            for key, value in payload.items():
                if str(key).startswith("$") or "." in str(key):
                    return True
                if self._contains_unsafe_data_keys(value):
                    return True
        elif isinstance(payload, list):
            for item in payload:
                if self._contains_unsafe_data_keys(item):
                    return True
        return False

    def _contains_unsafe_query_keys(self, payload: Any) -> bool:
        """For read/delete queries: allow a small safe set of Mongo operators."""
        if isinstance(payload, dict):
            for key, value in payload.items():
                key_str = str(key)

                if key_str.startswith("$") and key_str not in self.SAFE_QUERY_OPERATORS:
                    return True

                if not key_str.startswith("$") and "." in key_str:
                    return True

                if self._contains_unsafe_query_keys(value):
                    return True
        elif isinstance(payload, list):
            for item in payload:
                if self._contains_unsafe_query_keys(item):
                    return True
        return False

    @staticmethod
    def _sanitize_regex(value: str) -> str:
        return re.escape(value.strip())

    def create_record(self, data: Dict[str, Any]) -> Optional[str]:
        if not isinstance(data, dict) or not data:
            raise ValueError("Data must be a non-empty dictionary.")
        if self._contains_unsafe_data_keys(data):
            raise ValueError("Unsafe keys detected in input data.")

        try:
            result = self.collection.insert_one(data)
            self.logger.info("Inserted record id=%s", result.inserted_id)
            return str(result.inserted_id)
        except PyMongoError:
            self.logger.exception("Insert operation failed.")
            return None

    def get_record_by_id(self, record_id: str) -> Optional[Dict[str, Any]]:
        try:
            doc = self.collection.find_one({"_id": ObjectId(record_id)})
            return self._serialize_doc(doc) if doc else None
        except Exception:
            self.logger.exception("Failed to fetch record by id=%s", record_id)
            return None

    def get_records(self, criteria: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        criteria = criteria or {}

        if not isinstance(criteria, dict):
            raise ValueError("Criteria must be a dictionary.")
        if self._contains_unsafe_query_keys(criteria):
            raise ValueError("Unsafe keys detected in search criteria.")

        try:
            docs = list(self.collection.find(criteria))
            return [self._serialize_doc(doc) for doc in docs]
        except PyMongoError:
            self.logger.exception("Fetch operation failed.")
            return []

    def update_record(self, query: Dict[str, Any], new_values: Dict[str, Any]) -> Dict[str, int]:
        if not isinstance(query, dict) or not query:
            raise ValueError("Query must be a non-empty dictionary.")
        if not isinstance(new_values, dict) or not new_values:
            raise ValueError("New values must be a non-empty dictionary.")
        if self._contains_unsafe_query_keys(query):
            raise ValueError("Unsafe keys detected in update query.")
        if self._contains_unsafe_data_keys(new_values):
            raise ValueError("Unsafe keys detected in update data.")

        try:
            result = self.collection.update_many(query, {"$set": new_values})
            self.records_updated = result.modified_count
            self.records_matched = result.matched_count
            self.logger.info(
                "Update complete. matched=%s modified=%s",
                result.matched_count, result.modified_count
            )
            return {"matched": result.matched_count, "modified": result.modified_count}
        except PyMongoError:
            self.logger.exception("Update operation failed.")
            return {"matched": 0, "modified": 0}

    def delete_record(self, query: Dict[str, Any]) -> int:
        if not isinstance(query, dict) or not query:
            raise ValueError("Query must be a non-empty dictionary.")
        if self._contains_unsafe_query_keys(query):
            raise ValueError("Unsafe keys detected in delete query.")

        try:
            result = self.collection.delete_many(query)
            self.records_deleted = result.deleted_count
            self.logger.info("Delete complete. deleted=%s", result.deleted_count)
            return result.deleted_count
        except PyMongoError:
            self.logger.exception("Delete operation failed.")
            return 0

    def search_by_breed_keyword(self, keyword: str) -> List[Dict[str, Any]]:
        if not keyword or not isinstance(keyword, str):
            return []

        safe_keyword = self._sanitize_regex(keyword)
        query = {"breed": {"$regex": safe_keyword, "$options": "i"}}
        return self.get_records(query)